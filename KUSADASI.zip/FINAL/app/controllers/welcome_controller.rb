class WelcomeController < ApplicationController
  def index
  	
  end
end
